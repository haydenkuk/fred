from .fred import Fred

__all__ = [
  'Fred'
]